#Resources

##Presentations
To see all the presentations: visit our shared google drive folder [Here](https://drive.google.com/drive/folders/0B-jYUqKknN4QfldkRVJFSFAybEhTQ3N4WVNkRHA0Tkoyb3h0OUxsMnhGYU5KTnBfSDZHcnc)

If you need any explanations or have any questions, just contact us at our livetutor Moxtra-API based system (made by @ethanlee16)

##Documents
To see the pdf versions of most of the material we will be teaching in class, just visit the corresponding folder above

